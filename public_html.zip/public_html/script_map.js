document.addEventListener('DOMContentLoaded', function() {
    var aquamarin = document.getElementById('AQUAMARIN');
    var aquamarinPopup = document.getElementById('aquamarin-popup');
    
    aquamarin.addEventListener('click', function() {
        // Toggle visibility
        if (aquamarinPopup.style.display === 'none' || aquamarinPopup.style.display === '') {
            aquamarinPopup.style.display = 'block';
        } else {
            aquamarinPopup.style.display = 'none';
        }
    });

    // Schließen das Popup, wenn außerhalb davon geklickt wird:
    window.addEventListener('click', function(event) {
        if (event.target !== aquamarin && event.target !== aquamarinPopup) {
            aquamarinPopup.style.display = 'none';
        }
    });
});

document.addEventListener('DOMContentLoaded', function() {
    var smaragd = document.getElementById('SMARAGD');
    var smaragdPopup = document.getElementById('smaragd-popup');
    
    smaragd.addEventListener('click', function() {
        // Toggle visibility
        if (smaragdPopup.style.display === 'none' || smaragdPopup.style.display === '') {
            smaragdPopup.style.display = 'block';
        } else {
            smaragdPopup.style.display = 'none';
        }
    });

    // Schließen das Popup, wenn außerhalb davon geklickt wird:
    window.addEventListener('click', function(event) {
        if (event.target !== smaragd && event.target !== smaragdPopup) {
            smaragdPopup.style.display = 'none';
        }
    });
});

document.addEventListener('DOMContentLoaded', function() {
    var topas = document.getElementById('TOPAS');
    var topasPopup = document.getElementById('topas-popup');
    
    topas.addEventListener('click', function() {
        // Toggle visibility
        if (topasPopup.style.display === 'none' || topasPopup.style.display === '') {
            topasPopup.style.display = 'block';
        } else {
            topasPopup.style.display = 'none';
        }
    });

    // Schließen das Popup, wenn außerhalb davon geklickt wird:
    window.addEventListener('click', function(event) {
        if (event.target !== topas && event.target !== topasPopup) {
            topasPopup.style.display = 'none';
        }
    });
});

document.addEventListener('DOMContentLoaded', function() {
    var mondstein = document.getElementById('MONDSTEIN');
    var mondsteinPopup = document.getElementById('mondstein-popup');
    
    mondstein.addEventListener('click', function() {

        if (mondsteinPopup.style.display === 'none' || mondsteinPopup.style.display === '') {
            mondsteinPopup.style.display = 'block';
        } else {
            mondsteinPopup.style.display = 'none';
        }
    });


    window.addEventListener('click', function(event) {
        if (event.target !== mondstein && event.target !== mondsteinPopup) {
            mondsteinPopup.style.display = 'none';
        }
    });
});

document.addEventListener('DOMContentLoaded', function() {
    var diamant = document.getElementById('DIAMANT');
    var diamantPopup = document.getElementById('diamant-popup');
    
    diamant.addEventListener('click', function() {

        if (diamantPopup.style.display === 'none' || diamantPopup.style.display === '') {
            diamantPopup.style.display = 'block';
        } else {
            diamantPopup.style.display = 'none';
        }
    });


    window.addEventListener('click', function(event) {
        if (event.target !== diamant && event.target !== diamantPopup) {
            diamantPopup.style.display = 'none';
        }
    });
});

document.addEventListener('DOMContentLoaded', function() {
    var saphir = document.getElementById('SAPHIR');
    var saphirPopup = document.getElementById('saphir-popup');
    
    saphir.addEventListener('click', function() {

        if (saphirPopup.style.display === 'none' || saphirPopup.style.display === '') {
            saphirPopup.style.display = 'block';
        } else {
            saphirPopup.style.display = 'none';
        }
    });


    window.addEventListener('click', function(event) {
        if (event.target !== saphir && event.target !== saphirPopup) {
            saphirPopup.style.display = 'none';
        }
    });
});

document.addEventListener('DOMContentLoaded', function() {
    var opal = document.getElementById('OPAL');
    var opalPopup = document.getElementById('opal-popup');
    
    opal.addEventListener('click', function() {

        if (opalPopup.style.display === 'none' || opalPopup.style.display === '') {
            opalPopup.style.display = 'block';
        } else {
            opalPopup.style.display = 'none';
        }
    });


    window.addEventListener('click', function(event) {
        if (event.target !== opal && event.target !== opalPopup) {
            opalPopup.style.display = 'none';
        }
    });
});

document.addEventListener('DOMContentLoaded', function() {
    var peridot = document.getElementById('PERIDOT');
    var peridotPopup = document.getElementById('peridot-popup');
    
    peridot.addEventListener('click', function() {

        if (peridotPopup.style.display === 'none' || peridotPopup.style.display === '') {
            peridotPopup.style.display = 'block';
        } else {
            peridotPopup.style.display = 'none';
        }
    });


    window.addEventListener('click', function(event) {
        if (event.target !== peridot && event.target !== peridotPopup) {
            peridotPopup.style.display = 'none';
        }
    });
});

document.addEventListener('DOMContentLoaded', function() {
    var tansanit = document.getElementById('TANSANIT');
    var tansanitPopup = document.getElementById('tansanit-popup');
    
    tansanit.addEventListener('click', function() {

        if (tansanitPopup.style.display === 'none' || tansanitPopup.style.display === '') {
            tansanitPopup.style.display = 'block';
        } else {
            tansanitPopup.style.display = 'none';
        }
    });


    window.addEventListener('click', function(event) {
        if (event.target !== tansanit && event.target !== tansanitPopup) {
            tansanitPopup.style.display = 'none';
        }
    });
});

document.addEventListener('DOMContentLoaded', function() {
    var rubin = document.getElementById('RUBIN');
    var rubinPopup = document.getElementById('rubin-popup');
    
    rubin.addEventListener('click', function() {

        if (rubinPopup.style.display === 'none' || rubinPopup.style.display === '') {
            rubinPopup.style.display = 'block';
        } else {
            rubinPopup.style.display = 'none';
        }
    });


    window.addEventListener('click', function(event) {
        if (event.target !== rubin && event.target !== rubinPopup) {
            rubinPopup.style.display = 'none';
        }
    });
});

document.addEventListener('DOMContentLoaded', function() {
    var granat = document.getElementById('GRANAT');
    var granatPopup = document.getElementById('granat-popup');
    
    granat.addEventListener('click', function() {

        if (granatPopup.style.display === 'none' || granatPopup.style.display === '') {
            granatPopup.style.display = 'block';
        } else {
            granatPopup.style.display = 'none';
        }
    });


    window.addEventListener('click', function(event) {
        if (event.target !== granat && event.target !== granatPopup) {
            granatPopup.style.display = 'none';
        }
    });
});

document.addEventListener('DOMContentLoaded', function() {
    var amethyst = document.getElementById('AMETHYST');
    var amethystPopup = document.getElementById('amethyst-popup');
    
    amethyst.addEventListener('click', function() {

        if (amethystPopup.style.display === 'none' || amethystPopup.style.display === '') {
            amethystPopup.style.display = 'block';
        } else {
            amethystPopup.style.display = 'none';
        }
    });


    window.addEventListener('click', function(event) {
        if (event.target !== amethyst && event.target !== amethystPopup) {
            amethystPopup.style.display = 'none';
        }
    });
});

