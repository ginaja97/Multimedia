document.addEventListener('DOMContentLoaded', function() {
    // Funktion zur Behandlung der Klick-Ereignisse
    function setupPopup(gemId, popupId) {
        var gemElement = document.getElementById(gemId);
        var popupElement = document.getElementById(popupId);

        gemElement.addEventListener('click', function(event) {
            // Stoppt das Klick-Ereignis vom Propagieren zum Window-Event
            event.stopPropagation();
            // Schließt alle Popups
            closeAllPopups();
            // Toggle visibility
            if (popupElement.style.display === 'none' || popupElement.style.display === '') {
                popupElement.style.display = 'block';
            } else {
                popupElement.style.display = 'none';
            }
        });

        // Schließen das Popup, wenn außerhalb davon geklickt wird
        window.addEventListener('click', function(event) {
            if (event.target !== gemElement && event.target !== popupElement) {
                popupElement.style.display = 'none';
            }
        });

        // Verhindert das Schließen des Popups beim Klicken darauf
        popupElement.addEventListener('click', function(event) {
            event.stopPropagation();
        });
    }

    // Funktion zum Schließen aller Popups
    function closeAllPopups() {
        var popups = document.querySelectorAll('.popup');
        popups.forEach(function(popup) {
            popup.style.display = 'none';
        });
    }

    // Initialisieren der Popups für alle Edelsteine
    setupPopup('AQUAMARIN', 'aquamarin-popup');
    setupPopup('SMARAGD', 'smaragd-popup');
    setupPopup('TOPAS', 'topas-popup');
    setupPopup('MONDSTEIN', 'mondstein-popup');
    setupPopup('DIAMANT', 'diamant-popup');
    setupPopup('SAPHIR', 'saphir-popup');
    setupPopup('OPAL', 'opal-popup');
    setupPopup('PERIDOT', 'peridot-popup');
    setupPopup('TANSANIT', 'tansanit-popup');
    setupPopup('RUBIN', 'rubin-popup');
    setupPopup('GRANAT', 'granat-popup');
    setupPopup('AMETHYST', 'amethyst-popup');
});